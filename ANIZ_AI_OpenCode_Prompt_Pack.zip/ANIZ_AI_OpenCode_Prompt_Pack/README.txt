ANIZ AI — OpenCode Prompt Pack

1. Extract this ZIP.
2. Open your ANIZ AI project folder in VS Code.
3. Open OpenCode from that project folder so it can inspect the repository.
4. Open MASTER_PROMPT.md, copy its contents, and paste them into OpenCode.
5. Let OpenCode inspect the project first. Review its plan before approving risky actions.
6. Keep secrets/API keys in local environment configuration; never paste them into source files or commit them.

Important:
- This prompt tells OpenCode to inspect and preserve your existing work before changing anything.
- It does not magically give ANIZ AI browser, desktop, or video-editing access. Those require real integrations.
- Use supervised mode for deleting files, installing software, changing settings, publishing, or other consequential actions.
